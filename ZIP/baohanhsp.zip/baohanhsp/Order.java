package Contest.Class_and_Java_Collections.baohanhsp;

public class Order implements Comparable<Order> {
    private Customer customer;
    private Product product;

    public Order(Customer customer, Product product) {
        this.customer = customer;
        this.product = product;
    }

    public String getCustomerId() {
        return customer.getId();
    }

    public String getCustomerName() {
        return customer.getName();
    }

    public String getCustomerAddress() {
        return customer.getAddress();
    }

    public String getProductID() {
        return product.getProductID();
    }

    public int getTotalPrice() {
        return product.getPrice() * customer.getNum();
    }

    public String calculateWarrantyEndDate() {
        String[] dateParts = customer.getDate().split("/");
        int day = Integer.parseInt(dateParts[0]);
        int month = Integer.parseInt(dateParts[1]) + product.getBaohanh();
        int year = Integer.parseInt(dateParts[2]);

        if (month > 12) {
            year += month / 12;
            month = month % 12;
        }

        if (month == 0) {
            month = 12;
            year--;
        }

        return String.format("%02d/%02d/%04d", day, month, year);
    }

    @Override
    public String toString() {
        return String.format("%s %s %s %s %d %s",
                getCustomerId(),
                getCustomerName(),
                getCustomerAddress(),
                getProductID(),
                getTotalPrice(),
                calculateWarrantyEndDate());
    }

    @Override
    public int compareTo(Order other) {
        String thisWarrantyDate = this.calculateWarrantyEndDate();
        String otherWarrantyDate = other.calculateWarrantyEndDate();

        int dateComparison = thisWarrantyDate.compareTo(otherWarrantyDate);
        if (dateComparison != 0) {
            return dateComparison;
        }
        return this.getCustomerId().compareTo(other.getCustomerId());
    }
}
