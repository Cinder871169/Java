package Contest.Class_and_Java_Collections.dongphuc;

public class Dangky {
    private String msv;
    private String size;

    public Dangky(String msv, String size) {
        this.msv = msv;
        this.size = size;
    }

    public String getMsv() {
        return msv;
    }

    public String getSize() {
        return size;
    }

}
