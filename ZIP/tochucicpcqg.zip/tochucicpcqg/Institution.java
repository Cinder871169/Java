package Contest.Class_and_Java_Collections.tochucicpcqg;

public class Institution {
    private String schoolID, schoolName;

    public Institution(String schoolID, String schoolName) {
        this.schoolID = schoolID;
        this.schoolName = schoolName;
    }

    public String getSchoolID() {
        return schoolID;
    }

    public String getSchoolName() {
        return schoolName;
    }
}
